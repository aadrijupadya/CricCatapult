# CricCatapult

#### A novel data package with a focus on data visualization, easy access to data, and data analysis
