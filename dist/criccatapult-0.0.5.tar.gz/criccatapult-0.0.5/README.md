# CricCatapult

#### A novel data package with a focus on data visualization, easy access to data, and data analysis

Packaging is still in progress (most likely will not work) https://pypi.org/project/criccatapult/0.0.3

### To run/test out this package, simply clone the project and run it locally.
